<footer class="site-footer">
    <div class="container">
      <div class="row" style="text-align:left">
        <div class="col-sm-12 col-md-6  ">
          <h6>About</h6>
          <p>Grocify. Web Progamming 2021. Lorem ipsum dolor sit amet consectetur adipisicing elit. Similique nobis reprehenderit, quis repellendus eaque quibusdam. Maxime, vero reiciendis voluptate repellat possimus similique inventore officiis ad soluta enim. Deleniti, maxime fuga?</p>
        </div>
        <div class="col-xs-6 col-md-3">
          <h6>Quick Links</h6>
          <ul class="footer-links">
            <li><a href="acc_details.html">My Account</a></li>
            <li><a href="acc_orders.html">My Orders</a></li>
            <li><a href="contactus.html">Help</a></li>
          </ul>
        </div>
        <div class="col-xs-6 col-md-3">
          <h6>Categories</h6>
          <ul class="footer-links">
            <li><a href="product.html">Dry and Canned Food</a></li>
            <li><a href="product.html">Meat and Seafood</a></li>
            <li><a href="product.html">Fresh Produce</a></li>
            <li><a href="product.html">Drinks</a></li>
            <li><a href="product.html">Dairy and Eggs</a></li>

          </ul>
        </div>

        
      </div>
      <hr>
    </div>
    <div class="container">
      <div class="row" style="text-align:left">
        <div class="col-md-8 col-sm-6 col-xs-12">
          <p class="copyright-text">Copyright &copy; 2017 All Rights Reserved by 
       <a href="#">GROCIFY</a>.
          </p>
        </div>

        <div class="col-md-4 col-sm-6 col-xs-12">
          <ul class="social-icons">
            <li><a class="facebook" href="#"><i class="fab fa-facebook-f"></i></a></li>
            <li><a class="twitter" href="#"><i class="fab fa-twitter"></i></a></li>
            <li><a class="dribbble" href="#"><i class="fab fa-dribbble"></i></a></li>
            <li><a class="linkedin" href="#"><i class="fab   fa-linkedin"></i></a></li>   
          </ul>
        </div>
      </div>
    </div>
</footer>